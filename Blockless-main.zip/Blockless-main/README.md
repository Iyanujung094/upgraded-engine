# Blockless Node Installation Guide

This guide will help you set up and configure a Blockless node with EigenLayer integration. The installation script automates the entire process, from setting up prerequisites to configuring your operator.

# First Step

Before proceeding with the installation, please register at:
Blockless Network [Registration](https://bless.network/dashboard?ref=ZVIGT0)

## Prerequisites

- Ubuntu/Debian-based system
- Root access or sudo privileges
- Minimum 2 GB RAM
- At least 50 GB storage
- Stable internet connection

## Getting Started

1. Using wget

```bash
wget https://raw.githubusercontent.com/Galkurta/Blockless/main/blockless.sh && chmod +x blockless.sh && sudo ./blockless.sh
```

2. Using curl

```bash
curl -fsSL https://raw.githubusercontent.com/Galkurta/Blockless/main/blockless.sh -o blockless.sh && chmod +x blockless.sh && sudo ./blockless.sh
```

## Installation Steps

The script will automatically:

1. Install prerequisites (git, curl, wget, jq)
2. Configure firewall rules
3. Install and configure Docker
4. Install b7s (Blockless Node)
5. Install EigenLayer CLI
6. Create operator keys (ECDSA and BLS)
7. Create and configure metadata
8. Register operator

## Configuration Files

After installation, you'll find these important files:

- `$HOME/blockless/metadata.json` - Operator metadata configuration
- `$HOME/blockless/operator.yaml` - Operator main configuration
- `$HOME/.eigenlayer/operator_keys/` - Directory containing your keys

## Metadata Setup

After the script creates your metadata.json:

1. Download the metadata file from your VPS:

```bash
scp root@YOUR-VPS-IP:/root/blockless/metadata.json .
```

2. Create a GitHub repository and upload the metadata.json file

3. Get the raw URL of your metadata.json:

   - Open the file in GitHub
   - Click "Raw" button
   - Copy the URL (Example: https://raw.githubusercontent.com/Username/Repository/refs/heads/main/metadata.json)

4. Input this URL when prompted by the script

## Helper Scripts

The installation creates several helper scripts:

- `update.sh` - Updates the Blockless node
- `backup.sh` - Creates a backup of your configuration
- `monitor.sh` - Monitors node status

## Common Commands

```bash
# Check worker logs
docker logs -f blockless-worker

# Check operator status
eigenlayer operator status $HOME/blockless/operator.yaml

# List your keys
eigenlayer operator keys list

# Export your keys
eigenlayer operator keys export --key-type ecdsa YOUR-KEY-NAME
```

## Important Notes

1. Ensure you have funded your ECDSA wallet with at least 1 ETH before registration
2. Keep your keys and configuration files backed up securely
3. Monitor your node regularly using the provided monitoring script

## Troubleshooting

If you encounter issues:

1. Check the logs:

```bash
docker logs blockless-worker
```

2. Verify your configuration:

```bash
cat $HOME/blockless/operator.yaml
```

3. Ensure your metadata URL is accessible
4. Verify your RPC endpoint is working

## Support

If you need assistance, you can:

- Check the [Official Blockless Documentation](https://docs.bless.network/#/)
- Open an issue in this repository

## License

[MIT License](LICENSE)

## Disclaimer

Please make sure to back up all your keys and configurations. The authors are not responsible for any loss of funds or issues arising from the use of this script.
