#!/bin/bash

# Colors for better visibility
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored messages
print_message() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if command was successful
check_status() {
    if [ $? -eq 0 ]; then
        print_message "$1 completed successfully"
    else
        print_error "$1 failed"
        exit 1
    fi
}

# Function to check if Docker is installed
check_docker() {
    if command -v docker &> /dev/null; then
        print_message "Docker is already installed"
        return 0
    else
        return 1
    fi
}

# Function to validate string against regex
validate_regex() {
    local string=$1
    local regex=$2
    if [[ $string =~ $regex ]]; then
        return 0
    else
        return 1
    fi
}

# Function to check image file
check_image() {
    local image_path=$1
    
    # Check if file exists
    if [ ! -f "$image_path" ]; then
        print_error "Image file not found"
        return 1
    fi
    
    # Check file extension
    if [[ ! $image_path =~ \.png$ ]]; then
        print_error "Image must be a PNG file"
        return 1
    fi
    
    # Check file size (must be less than 1MB = 1048576 bytes)
    local size=$(stat -f%z "$image_path" 2>/dev/null || stat -c%s "$image_path")
    if [ $size -gt 1048576 ]; then
        print_error "Image size must be less than 1MB"
        return 1
    fi
    
    return 0
}

# Function to get ECDSA address with retries
get_ecdsa_address() {
    local key_name=$1
    local max_retries=5
    local retry_count=0
    local address=""

    print_message "Waiting for key file generation..."
    sleep 5  # Give more time for key file to be generated

    while [ $retry_count -lt $max_retries ]; do
        # Try to get address from key file first (more reliable)
        if [ -f "$HOME/.eigenlayer/operator_keys/$key_name.ecdsa.key.json" ]; then
            address=$(jq -r '.address' "$HOME/.eigenlayer/operator_keys/$key_name.ecdsa.key.json")
            if [ -n "$address" ] && [ "$address" != "null" ] && [[ "$address" =~ ^0x[a-fA-F0-9]{40}$ ]]; then
                echo "$address"
                return 0
            fi
        fi

        # Fallback: try to get from keys list
        address=$(eigenlayer operator keys list 2>/dev/null | grep -A1 "ECDSA Key" | grep "Address:" | cut -d':' -f2 | tr -d ' ')
        if [ -n "$address" ] && [[ "$address" =~ ^0x[a-fA-F0-9]{40}$ ]]; then
            echo "$address"
            return 0
        fi

        print_warning "Attempt $((retry_count+1))/$max_retries: Waiting for ECDSA address..."
        sleep 3
        retry_count=$((retry_count+1))
    done

    return 1
}

# Welcome message
clear
echo -e "${GREEN}"
echo "██████╗ ██╗      ██████╗  ██████╗██╗  ██╗██╗     ███████╗███████╗███████╗"
echo "██╔══██╗██║     ██╔═══██╗██╔════╝██║ ██╔╝██║     ██╔════╝██╔════╝██╔════╝"
echo "██████╔╝██║     ██║   ██║██║     █████╔╝ ██║     █████╗  ███████╗███████╗"
echo "██╔══██╗██║     ██║   ██║██║     ██╔═██╗ ██║     ██╔══╝  ╚════██║╚════██║"
echo "██████╔╝███████╗╚██████╔╝╚██████╗██║  ██╗███████╗███████╗███████║███████║"
echo "╚═════╝ ╚══════╝ ╚═════╝  ╚═════╝╚═╝  ╚═╝╚══════╝╚══════╝╚══════╝╚══════╝"
echo -e "${NC}"
echo "=================================================================="
echo "                  Blockless Auto Installation                   "
echo "                     Author: Galkurta                      "
echo "            Join our community: https://t.me/galkurtarchive           "
echo "=================================================================="
echo ""

# Ask for confirmation to proceed
read -p "Do you want to proceed with the installation? (y/n): " confirm
if [[ $confirm != "y" && $confirm != "Y" ]]; then
    exit 0
fi

# Create installation directory
INSTALL_DIR="$HOME/blockless"
mkdir -p $INSTALL_DIR
cd $INSTALL_DIR

# Step 1: Installing Prerequisites
print_message "Step 1: Installing Prerequisites..."
sudo apt update && sudo apt upgrade -y
check_status "System update"

sudo apt-get install git curl wget jq -y
check_status "Git and utilities installation"

# Configure UFW
print_message "Configuring firewall rules..."
sudo ufw allow 9527/tcp
sudo ufw allow 9527
sudo ufw allow 31783/tcp
sudo ufw allow 30564/tcp
check_status "Firewall configuration"

# Step 2: Docker Installation (if not already installed)
if ! check_docker; then
    print_message "Step 2: Installing Docker..."
    sudo apt install docker.io -y
    sudo systemctl start docker
    sudo systemctl enable docker
    sudo curl -L "https://github.com/docker/compose/releases/download/v2.29.2/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    sudo chmod +x /usr/local/bin/docker-compose
    check_status "Docker installation"
    
    # Verify Docker installation
    docker_version=$(docker --version)
    print_message "Docker version: $docker_version"
fi

# Step 3: Install b7s
print_message "Step 3: Installing b7s..."
if sudo sh -c "curl https://raw.githubusercontent.com/blocklessnetwork/b7s/main/download.sh | bash"; then
    check_status "b7s installation (curl method)"
elif sudo sh -c "wget https://raw.githubusercontent.com/blocklessnetwork/b7s/main/download.sh -v -O download.sh; chmod +x download.sh; ./download.sh; rm -rf download.sh"; then
    check_status "b7s installation (wget method)"
else
    print_error "b7s installation failed using both methods"
    exit 1
fi

# Pull Docker image
print_message "Pulling Blockless Docker image..."
docker pull ghcr.io/blocklessnetwork/b7s:v0.6.2
check_status "Docker image pull"

# Create directories for keys and db
mkdir -p $INSTALL_DIR/keys
mkdir -p $INSTALL_DIR/db

# Step 4: Setup Worker Node
print_message "Step 4: Setting up Worker Node..."
docker run --platform=linux/amd64 -d \
-e NODE_ROLE=worker \
-e BOOT_NODES=/ip4/146.190.197.136/tcp/31783/p2p/12D3KooWMUFNmnPBEZY5y7qqB8F6eVEzfPXG7KAd1v1FV1Q44A6d,/ip4/209.38.5.92/tcp/30564/p2p/12D3KooWK2qKNvmuYeQ7TFSkja8wqgSdvpfEYKgqkvRSf1GtpHEN \
-v $INSTALL_DIR/keys:/app/keys \
-v $INSTALL_DIR/db:/app/db \
-p 9527:9527 \
--name blockless-worker \
ghcr.io/blocklessnetwork/b7s:v0.6.2
check_status "Worker node setup"

# Step 5: Install EigenLayer CLI and setup PATH
print_message "Step 5: Installing EigenLayer CLI..."
curl -sSfL https://raw.githubusercontent.com/layr-labs/eigenlayer-cli/master/scripts/install.sh | sh -s
check_status "EigenLayer CLI installation"

# Add eigenlayer to PATH and environment variables
print_message "Setting up EigenLayer CLI in PATH..."
EIGENLAYER_PATH="$HOME/.eigenlayer/bin"
export PATH="$PATH:$EIGENLAYER_PATH"

# Add to multiple shell configuration files for persistence
for shell_rc in "$HOME/.bashrc" "$HOME/.zshrc" "$HOME/.profile"; do
    if [ -f "$shell_rc" ]; then
        if ! grep -q "EIGENLAYER_PATH" "$shell_rc"; then
            echo "export EIGENLAYER_PATH=$EIGENLAYER_PATH" >> "$shell_rc"
            echo 'export PATH=$PATH:$EIGENLAYER_PATH' >> "$shell_rc"
        fi
    fi
done

# Create directory if it doesn't exist
mkdir -p $EIGENLAYER_PATH

# Move eigenlayer binary to the correct location if needed
if [ -f "/root/bin/eigenlayer" ]; then
    cp /root/bin/eigenlayer $EIGENLAYER_PATH/
    chmod +x $EIGENLAYER_PATH/eigenlayer
fi

# Source the updated configuration
source "$HOME/.bashrc" 2>/dev/null || source "$HOME/.profile" 2>/dev/null || true

# Verify eigenlayer installation with retries
max_retries=5
retry_count=0
while ! command -v eigenlayer &> /dev/null && [ $retry_count -lt $max_retries ]; do
    print_warning "Waiting for eigenlayer command to become available... (Attempt $((retry_count+1))/$max_retries)"
    sleep 2
    retry_count=$((retry_count+1))
    # Try to fix PATH if command is still not found
    export PATH="$PATH:$EIGENLAYER_PATH"
done

if ! command -v eigenlayer &> /dev/null; then
    print_error "eigenlayer command not found after $max_retries attempts. Manual intervention required."
    print_warning "Please run the following commands manually:"
    echo "export EIGENLAYER_PATH=$EIGENLAYER_PATH"
    echo "export PATH=\$PATH:\$EIGENLAYER_PATH"
    echo "source ~/.bashrc"
    exit 1
fi

print_message "eigenlayer successfully added to PATH"
eigenlayer --version
check_status "eigenlayer version check"

# Step 6: Create Operator Keys
print_message "Step 6: Creating Operator Keys..."

# Ask for key name
read -p "Enter a name for your operator keys: " KEY_NAME
print_message "Creating ECDSA key..."
eigenlayer operator keys create --key-type ecdsa $KEY_NAME
check_status "ECDSA key creation"

# Get ECDSA address with improved handling
print_message "Getting ECDSA address..."
# Wait a moment for key file to be created
sleep 5

# Get the key file path
KEY_FILE="$HOME/.eigenlayer/operator_keys/$KEY_NAME.ecdsa.key.json"

# Verify key file exists
if [ ! -f "$KEY_FILE" ]; then
    print_error "Key file not found at: $KEY_FILE"
    exit 1
fi

# Get raw address and clean it up
RAW_ADDRESS=$(cat "$KEY_FILE" | jq -r '.address' | tr -d '[:space:]')

# Clean up and format address
if [[ "$RAW_ADDRESS" =~ ^0x[a-fA-F0-9]{40}$ ]]; then
    ECDSA_ADDRESS="$RAW_ADDRESS"
elif [[ "$RAW_ADDRESS" =~ ^[a-fA-F0-9]{40}$ ]]; then
    ECDSA_ADDRESS="0x$RAW_ADDRESS"
else
    # Try to extract from operator keys list as fallback
    TEMP_ADDRESS=$(eigenlayer operator keys list | grep -A1 "ECDSA Key" | grep "Address:" | cut -d':' -f2 | tr -d '[:space:]')
    if [[ "$TEMP_ADDRESS" =~ ^0x[a-fA-F0-9]{40}$ ]]; then
        ECDSA_ADDRESS="$TEMP_ADDRESS"
    else
        print_error "Could not obtain valid ECDSA address"
        print_error "Raw address from file: $RAW_ADDRESS"
        print_error "Address from keys list: $TEMP_ADDRESS"
        exit 1
    fi
fi

print_message "ECDSA address found: $ECDSA_ADDRESS"

# Final validation
if ! [[ "$ECDSA_ADDRESS" =~ ^0x[a-fA-F0-9]{40}$ ]]; then
    print_error "Final address validation failed: $ECDSA_ADDRESS"
    exit 1
fi

print_message "ECDSA address validated successfully"

# Create BLS key
print_message "Creating BLS key..."
eigenlayer operator keys create --key-type bls $KEY_NAME
check_status "BLS key creation"

# Step 7: Create and Configure Operator
print_message "Step 7: Configuring Operator..."

# Metadata configuration
print_message "Configuring metadata..."

# Name validation (alphanumeric, spaces, and basic punctuation, 3-50 chars)
while true; do
    read -p "Enter operator name (3-50 chars, alphanumeric and basic punctuation): " OPERATOR_NAME
    if validate_regex "$OPERATOR_NAME" "^[a-zA-Z0-9 .,!?-]{3,50}$"; then
        break
    else
        print_error "Invalid name format. Please try again."
    fi
done

# Description validation (3-200 chars)
while true; do
    read -p "Enter operator description (3-200 chars): " OPERATOR_DESCRIPTION
    if validate_regex "$OPERATOR_DESCRIPTION" "^[a-zA-Z0-9 .,!?-]{3,200}$"; then
        break
    else
        print_error "Invalid description format. Please try again."
    fi
done

# Logo handling
print_message "Logo configuration..."
print_warning "Logo requirements:"
echo "1. Must be a PNG file"
echo "2. Must be less than 1MB in size"
echo "3. Must be accessible via public URL"

while true; do
    echo "Choose logo upload method:"
    echo "1. Use local PNG file (will be uploaded to temp.sh)"
    echo "2. Enter existing public URL"
    read -p "Enter your choice (1 or 2): " LOGO_CHOICE

    case $LOGO_CHOICE in
        1)
            read -p "Enter path to your PNG file: " LOGO_PATH
            if check_image "$LOGO_PATH"; then
                # Upload to temp.sh (7 day storage)
                print_message "Uploading logo to temp.sh..."
                LOGO_URL=$(curl -s -F "file=@$LOGO_PATH" https://temp.sh/upload | jq -r '.url')
                if [ -n "$LOGO_URL" ]; then
                    print_message "Logo uploaded successfully to: $LOGO_URL"
                    break
                else
                    print_error "Failed to upload logo"
                fi
            fi
            ;;
        2)
            read -p "Enter public URL of your PNG logo: " LOGO_URL
            if curl --output /dev/null --silent --head --fail "$LOGO_URL"; then
                if [[ $LOGO_URL =~ \.png$ ]]; then
                    break
                else
                    print_error "URL must point to a PNG file"
                fi
            else
                print_error "Invalid URL or URL not accessible"
            fi
            ;;
        *)
            print_error "Invalid choice"
            ;;
    esac
done

# Social media links (optional)
read -p "Enter website URL (optional): " WEBSITE_URL
read -p "Enter Twitter URL (optional): " TWITTER_URL
read -p "Enter Discord URL (optional): " DISCORD_URL

# Create metadata.json with proper formatting
cat > $INSTALL_DIR/metadata.json << EOF
{
   "name": "$OPERATOR_NAME",
   "description": "$OPERATOR_DESCRIPTION",
   "logo": "$LOGO_URL",
   "website": "${WEBSITE_URL:-""}",
   "twitter": "${TWITTER_URL:-""}",
   "discord": "${DISCORD_URL:-""}"
}
EOF

print_message "Created metadata.json with validated information"

# Validate metadata.json size
METADATA_SIZE=$(stat -f%z "$INSTALL_DIR/metadata.json" 2>/dev/null || stat -c%s "$INSTALL_DIR/metadata.json")
if [ $METADATA_SIZE -gt 4096 ]; then
   print_error "metadata.json size exceeds 4KB limit. Please reduce content size."
   exit 1
fi

# Metadata URL configuration
print_message "Configuring metadata URL..."
print_warning "Please prepare your raw GitHub URL:"
echo "Example format: https://raw.githubusercontent.com/Username/Repository/refs/heads/branch/metadata.json"
echo "Sample URL: https://raw.githubusercontent.com/Galkurta/Eigen-Operator/refs/heads/main/metadata.json"

# Get metadata URL
read -p "Enter your metadata URL: " METADATA_URL

# Validate URL accessibility
print_message "Validating metadata URL..."
if ! curl --output /dev/null --silent --head --fail "$METADATA_URL"; then
   print_error "Metadata URL is not accessible"
   print_error "Please make sure:"
   echo "1. The URL is correct"
   echo "2. The repository is public"
   echo "3. The file exists in the repository"
   exit 1
fi
print_message "Metadata URL is valid and accessible"

# Create operator.yaml
print_message "Configuring ETH RPC URL..."
print_warning "You can use public RPC URLs such as:"
echo "1. https://ethereum-holesky.publicnode.com"
echo "2. https://1rpc.io/holesky"
echo "3. https://rpc.ankr.com/eth_holesky"
echo "Or use your own RPC URL from Infura/Alchemy"

# Ask for RPC URL with default value
default_rpc="https://ethereum-holesky.publicnode.com"
read -p "Enter your ETH RPC URL (press Enter to use $default_rpc): " ETH_RPC_URL
ETH_RPC_URL=${ETH_RPC_URL:-$default_rpc}

# Validate RPC URL
print_message "Validating RPC URL..."
while ! curl --output /dev/null --silent --head --fail "$ETH_RPC_URL"; do
   print_error "Invalid or inaccessible RPC URL"
   read -p "Please enter a valid ETH RPC URL: " ETH_RPC_URL
done
print_message "RPC URL validated successfully"

# Create operator.yaml with RPC configuration
print_message "Creating operator configuration..."
cat > $INSTALL_DIR/operator.yaml << EOF
operator:
 address: "$ECDSA_ADDRESS"
 delegation_approver_address: "0x0000000000000000000000000000000000000000"
 staker_opt_out_window_blocks: 0
 metadata_url: "$METADATA_URL"

el_delegation_manager_address: "0x83f8F8f0BB125F7870F6bfCf76853f874C330D76"
eth_rpc_url: "$ETH_RPC_URL"
chain_id: 17000
signer_type: "local_keystore"
private_key_store_path: "$HOME/.eigenlayer/operator_keys/$KEY_NAME.ecdsa.key.json"
EOF

print_message "Created operator.yaml with validated information"

# Step 8: Register Operator
print_warning "IMPORTANT: Before proceeding with registration, please ensure you have:"
echo "1. Funded your ECDSA wallet ($ECDSA_ADDRESS) with at least 1 ETH"
echo "2. Updated the metadata.json file with your correct information"
echo "3. Verified the operator.yaml configuration"

read -p "Do you want to proceed with operator registration? (y/n): " register_confirm
if [[ $register_confirm == "y" || $register_confirm == "Y" ]]; then
   print_message "Registering operator..."
   eigenlayer operator register "$INSTALL_DIR/operator.yaml"
   check_status "Operator registration"
   
   print_message "Checking operator status..."
   eigenlayer operator status "$INSTALL_DIR/operator.yaml"
fi

# Save current configuration
save_current_config() {
   local config_file="$INSTALL_DIR/node_config.txt"
   cat > "$config_file" << EOF
# Blockless Node Configuration
ECDSA_ADDRESS=$ECDSA_ADDRESS
KEY_NAME=$KEY_NAME
OPERATOR_NAME=$OPERATOR_NAME
INSTALL_DIR=$INSTALL_DIR

# Important Paths
EIGENLAYER_PATH=$EIGENLAYER_PATH
KEYS_DIR=$HOME/.eigenlayer/operator_keys
WORKER_KEYS=$INSTALL_DIR/keys
WORKER_DB=$INSTALL_DIR/db
EOF
   print_message "Configuration saved to: $config_file"
}

# Create helper scripts
create_helper_scripts() {
   # Create update script
   cat > $INSTALL_DIR/update.sh << EOF
#!/bin/bash
# Script to update Blockless node

# Pull latest Docker image
docker pull ghcr.io/blocklessnetwork/b7s:v0.6.2

# Stop current container
docker stop blockless-worker
docker rm blockless-worker

# Start new container
docker run --platform=linux/amd64 -d \
-e NODE_ROLE=worker \
-e BOOT_NODES=/ip4/146.190.197.136/tcp/31783/p2p/12D3KooWMUFNmnPBEZY5y7qqB8F6eVEzfPXG7KAd1v1FV1Q44A6d,/ip4/209.38.5.92/tcp/30564/p2p/12D3KooWK2qKNvmuYeQ7TFSkja8wqgSdvpfEYKgqkvRSf1GtpHEN \
-v $INSTALL_DIR/keys:/app/keys \
-v $INSTALL_DIR/db:/app/db \
-p 9527:9527 \
--name blockless-worker \
ghcr.io/blocklessnetwork/b7s:v0.6.2
EOF
   chmod +x $INSTALL_DIR/update.sh

   # Create backup script
   cat > $INSTALL_DIR/backup.sh << EOF
#!/bin/bash
# Script to backup node keys and configuration

BACKUP_DIR="\$HOME/blockless_backup_\$(date +%Y%m%d_%H%M%S)"
mkdir -p "\$BACKUP_DIR"

# Backup keys
cp -r $HOME/.eigenlayer/operator_keys "\$BACKUP_DIR/"
cp $INSTALL_DIR/operator.yaml "\$BACKUP_DIR/"
cp $INSTALL_DIR/metadata.json "\$BACKUP_DIR/"
cp $INSTALL_DIR/node_config.txt "\$BACKUP_DIR/"

# Create backup info
echo "Backup created at: \$(date)" > "\$BACKUP_DIR/backup_info.txt"
echo "ECDSA Address: $ECDSA_ADDRESS" >> "\$BACKUP_DIR/backup_info.txt"
echo "Operator Name: $OPERATOR_NAME" >> "\$BACKUP_DIR/backup_info.txt"

tar -czf "\$BACKUP_DIR.tar.gz" -C "\$BACKUP_DIR" .
rm -rf "\$BACKUP_DIR"

echo "Backup created: \$BACKUP_DIR.tar.gz"
EOF
   chmod +x $INSTALL_DIR/backup.sh

   # Create monitoring script
   cat > $INSTALL_DIR/monitor.sh << EOF
#!/bin/bash
# Script to monitor node status

while true; do
   clear
   echo "=== Blockless Node Monitor ==="
   echo "Operator: $OPERATOR_NAME"
   echo "Address: $ECDSA_ADDRESS"
   echo ""
   
   echo "=== Node Status ==="
   docker ps -f name=blockless-worker --format "{{.Status}}"
   echo ""
   
   echo "=== Latest Logs ==="
   docker logs --tail 10 blockless-worker
   
   sleep 30
done
EOF
   chmod +x $INSTALL_DIR/monitor.sh
}

# Save configuration and create helper scripts
save_current_config
create_helper_scripts

# Print completion message and useful commands
echo ""
echo "=================================================="
echo "Installation and Configuration Completed!"
echo "=================================================="
echo ""
print_message "Useful commands:"
echo "1. Check worker logs:"
echo "   docker logs -f blockless-worker"
echo ""
echo "2. Check operator status:"
echo "   eigenlayer operator status $INSTALL_DIR/operator.yaml"
echo ""
echo "3. List your keys:"
echo "   eigenlayer operator keys list"
echo ""
echo "4. Export your keys (if needed):"
echo "   eigenlayer operator keys export --key-type ecdsa $KEY_NAME"
echo ""
echo "5. Update node:"
echo "   $INSTALL_DIR/update.sh"
echo ""
echo "6. Backup keys and config:"
echo "   $INSTALL_DIR/backup.sh"
echo ""
echo "7. Monitor node:"
echo "   $INSTALL_DIR/monitor.sh"
echo ""
print_message "Important files location:"
echo "1. Operator config: $INSTALL_DIR/operator.yaml"
echo "2. Metadata: $INSTALL_DIR/metadata.json"
echo "3. Keys directory: $HOME/.eigenlayer/operator_keys"
echo ""
print_warning "IMPORTANT: Please backup your keys and configuration files!"

# Final cleanup
print_message "Cleaning up installation files..."
rm -f $HOME/download.sh 2>/dev/null

print_message "Installation completed successfully!"
echo "Please make a secure backup of your keys and configuration."
echo "See $INSTALL_DIR/backup.sh for backup options."